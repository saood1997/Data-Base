MariaDB [(none)]> use themepark;
Database changed
MariaDB [themepark]> SELECT * FROM THEMEPARK;
+-----------+---------------+--------------+--------------+
| PARK_CODE | PARK_NAME     | PARK_CITY    | PARK_COUNTRY |
+-----------+---------------+--------------+--------------+
| FR1001    | FairyLand     | PARIS        | FR           |
| NL1202    | Efling        | NOORD        | NL           |
| SP4533    | AdventurePort | BARCELONA    | SP           |
| SW2323    | Labyrinthe    | LAUSANNE     | SW           |
| UK2622    | MiniLand      | WINDSOR      | UK           |
| UK3452    | PleasureLand  | STOKE        | UK           |
| ZA1342    | GoldTown      | JOHANNESBURG | ZA           |
+-----------+---------------+--------------+--------------+
7 rows in set (0.01 sec)

MariaDB [themepark]> SELECT PARK_NAME, PARK_CITY FROM THEMEPARK;
+---------------+--------------+
| PARK_NAME     | PARK_CITY    |
+---------------+--------------+
| FairyLand     | PARIS        |
| Efling        | NOORD        |
| AdventurePort | BARCELONA    |
| Labyrinthe    | LAUSANNE     |
| MiniLand      | WINDSOR      |
| PleasureLand  | STOKE        |
| GoldTown      | JOHANNESBURG |
+---------------+--------------+
7 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster  |          11 |               34 | FR1001    |
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10067 | FlightToStars   |          11 |               24 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10082 | NULL            |          10 |               40 | ZA1342    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30011 | BlackHole2      |          12 |               34 | UK3452    |
|      30012 | Pirates         |          10 |               42 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
11 rows in set (0.01 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE PARK_CODE = 'FR1001;'
    -> ;
Empty set (0.00 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE PARK_CODE = 'FR1001';
+-----------------+-------------+
| ATTRACT_NAME    | ATTRACT_AGE |
+-----------------+-------------+
| ThunderCoaster  |          11 |
| SpinningTeacups |           4 |
| FlightToStars   |          11 |
| Ant-Trap        |          23 |
| Carnival        |           3 |
+-----------------+-------------+
5 rows in set (0.00 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE PARK_CODE = 'FR1001' AND ATTRACT_AGE<10;
+-----------------+-------------+
| ATTRACT_NAME    | ATTRACT_AGE |
+-----------------+-------------+
| SpinningTeacups |           4 |
| Carnival        |           3 |
+-----------------+-------------+
2 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster  |          11 |               34 | FR1001    |
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10067 | FlightToStars   |          11 |               24 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10082 | NULL            |          10 |               40 | ZA1342    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30011 | BlackHole2      |          12 |               34 | UK3452    |
|      30012 | Pirates         |          10 |               42 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
11 rows in set (0.00 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE PARK_CODE = 'FR1001' AND PARK_CODE = 'UK3452' AND ATTRACT_AGE<10;
Empty set (0.00 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE PARK_CODE = 'FR1001' OR PARK_CODE = 'UK3452' AND ATTRACT_AGE<10;
+-----------------+-------------+
| ATTRACT_NAME    | ATTRACT_AGE |
+-----------------+-------------+
| ThunderCoaster  |          11 |
| SpinningTeacups |           4 |
| FlightToStars   |          11 |
| Ant-Trap        |          23 |
| Carnival        |           3 |
| 3D-Lego_Show    |           3 |
| UnderSeaWord    |           4 |
+-----------------+-------------+
7 rows in set (0.00 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE (PARK_CODE = 'FR1001' OR PARK_CODE = 'UK3452') AND ATTRACT_AGE<10;
+-----------------+-------------+
| ATTRACT_NAME    | ATTRACT_AGE |
+-----------------+-------------+
| SpinningTeacups |           4 |
| Carnival        |           3 |
| 3D-Lego_Show    |           3 |
| UnderSeaWord    |           4 |
+-----------------+-------------+
4 rows in set (0.00 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE PARK_CODE IN ('FR1001','UK3452') AND ATTRACT_AGE<10;
+-----------------+-------------+
| ATTRACT_NAME    | ATTRACT_AGE |
+-----------------+-------------+
| SpinningTeacups |           4 |
| Carnival        |           3 |
| 3D-Lego_Show    |           3 |
| UnderSeaWord    |           4 |
+-----------------+-------------+
4 rows in set (0.00 sec)

MariaDB [themepark]> SELECT ATTRACT_NAME, ATTRACT_AGE FROM ATTRACTION WHERE PARK_CODE not IN ('FR1001','UK3452') AND ATTRACT_AGE<10;
+--------------+-------------+
| ATTRACT_NAME | ATTRACT_AGE |
+--------------+-------------+
| GoldRush     |           5 |
+--------------+-------------+
1 row in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM THEMEPARK;
+-----------+---------------+--------------+--------------+
| PARK_CODE | PARK_NAME     | PARK_CITY    | PARK_COUNTRY |
+-----------+---------------+--------------+--------------+
| FR1001    | FairyLand     | PARIS        | FR           |
| NL1202    | Efling        | NOORD        | NL           |
| SP4533    | AdventurePort | BARCELONA    | SP           |
| SW2323    | Labyrinthe    | LAUSANNE     | SW           |
| UK2622    | MiniLand      | WINDSOR      | UK           |
| UK3452    | PleasureLand  | STOKE        | UK           |
| ZA1342    | GoldTown      | JOHANNESBURG | ZA           |
+-----------+---------------+--------------+--------------+
7 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM THEMEPARK WHERE PARK_COUNTRY = 'UK;'
    -> ;
Empty set (0.00 sec)

MariaDB [themepark]> SELECT * FROM THEMEPARK WHERE PARK_COUNTRY = 'UK';
+-----------+--------------+-----------+--------------+
| PARK_CODE | PARK_NAME    | PARK_CITY | PARK_COUNTRY |
+-----------+--------------+-----------+--------------+
| UK2622    | MiniLand     | WINDSOR   | UK           |
| UK3452    | PleasureLand | STOKE     | UK           |
+-----------+--------------+-----------+--------------+
2 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM THEMEPARK WHERE PARK_COUNTRY != 'UK';
+-----------+---------------+--------------+--------------+
| PARK_CODE | PARK_NAME     | PARK_CITY    | PARK_COUNTRY |
+-----------+---------------+--------------+--------------+
| FR1001    | FairyLand     | PARIS        | FR           |
| NL1202    | Efling        | NOORD        | NL           |
| SP4533    | AdventurePort | BARCELONA    | SP           |
| SW2323    | Labyrinthe    | LAUSANNE     | SW           |
| ZA1342    | GoldTown      | JOHANNESBURG | ZA           |
+-----------+---------------+--------------+--------------+
5 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM THEMEPARK WHERE PARK_COUNTRY <> 'UK';
+-----------+---------------+--------------+--------------+
| PARK_CODE | PARK_NAME     | PARK_CITY    | PARK_COUNTRY |
+-----------+---------------+--------------+--------------+
| FR1001    | FairyLand     | PARIS        | FR           |
| NL1202    | Efling        | NOORD        | NL           |
| SP4533    | AdventurePort | BARCELONA    | SP           |
| SW2323    | Labyrinthe    | LAUSANNE     | SW           |
| ZA1342    | GoldTown      | JOHANNESBURG | ZA           |
+-----------+---------------+--------------+--------------+
5 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster  |          11 |               34 | FR1001    |
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10067 | FlightToStars   |          11 |               24 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10082 | NULL            |          10 |               40 | ZA1342    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30011 | BlackHole2      |          12 |               34 | UK3452    |
|      30012 | Pirates         |          10 |               42 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
11 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION WHERE ATTRACT_NAME IS NOT NULL;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster  |          11 |               34 | FR1001    |
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10067 | FlightToStars   |          11 |               24 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30011 | BlackHole2      |          12 |               34 | UK3452    |
|      30012 | Pirates         |          10 |               42 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
10 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION WHERE ATTRACT_NAME IS NULL;
+------------+--------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+--------------+-------------+------------------+-----------+
|      10082 | NULL         |          10 |               40 | ZA1342    |
+------------+--------------+-------------+------------------+-----------+
1 row in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster  |          11 |               34 | FR1001    |
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10067 | FlightToStars   |          11 |               24 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10082 | NULL            |          10 |               40 | ZA1342    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30011 | BlackHole2      |          12 |               34 | UK3452    |
|      30012 | Pirates         |          10 |               42 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
11 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION WHERE ATTRACT_AGE > 10 AND ATTRACT_AGE <20;
+------------+----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME   | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster |          11 |               34 | FR1001    |
|      10067 | FlightToStars  |          11 |               24 | FR1001    |
|      30011 | BlackHole2     |          12 |               34 | UK3452    |
+------------+----------------+-------------+------------------+-----------+
3 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION WHERE ATTRACT_AGE BETWEEN 10 AND 20;
+------------+----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME   | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster |          11 |               34 | FR1001    |
|      10067 | FlightToStars  |          11 |               24 | FR1001    |
|      10082 | NULL           |          10 |               40 | ZA1342    |
|      30011 | BlackHole2     |          12 |               34 | UK3452    |
|      30012 | Pirates        |          10 |               42 | UK3452    |
+------------+----------------+-------------+------------------+-----------+
5 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION WHERE ATTRACT_AGE NOT BETWEEN 10 AND 20;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
6 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster  |          11 |               34 | FR1001    |
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10067 | FlightToStars   |          11 |               24 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10082 | NULL            |          10 |               40 | ZA1342    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30011 | BlackHole2      |          12 |               34 | UK3452    |
|      30012 | Pirates         |          10 |               42 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
11 rows in set (0.00 sec)

MariaDB [themepark]> SELECT DISTINCT PARK_CODE FROM ATTRACTION;
+-----------+
| PARK_CODE |
+-----------+
| FR1001    |
| UK3452    |
| ZA1342    |
+-----------+
3 rows in set (0.00 sec)

MariaDB [themepark]> SELECT DISTINCT (PARK_CODE) FROM ATTRACTION;
+-----------+
| PARK_CODE |
+-----------+
| FR1001    |
| UK3452    |
| ZA1342    |
+-----------+
3 rows in set (0.00 sec)

MariaDB [themepark]> SELECT DISTINCT(PARK_CODE), ATTRACT_NAME FROM ATTRACTION;
+-----------+-----------------+
| PARK_CODE | ATTRACT_NAME    |
+-----------+-----------------+
| FR1001    | ThunderCoaster  |
| FR1001    | SpinningTeacups |
| FR1001    | FlightToStars   |
| FR1001    | Ant-Trap        |
| ZA1342    | NULL            |
| FR1001    | Carnival        |
| UK3452    | 3D-Lego_Show    |
| UK3452    | BlackHole2      |
| UK3452    | Pirates         |
| UK3452    | UnderSeaWord    |
| ZA1342    | GoldRush        |
+-----------+-----------------+
11 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM ATTRACTION;
+------------+-----------------+-------------+------------------+-----------+
| ATTRACT_NO | ATTRACT_NAME    | ATTRACT_AGE | ATTRACT_CAPACITY | PARK_CODE |
+------------+-----------------+-------------+------------------+-----------+
|      10034 | ThunderCoaster  |          11 |               34 | FR1001    |
|      10056 | SpinningTeacups |           4 |               62 | FR1001    |
|      10067 | FlightToStars   |          11 |               24 | FR1001    |
|      10078 | Ant-Trap        |          23 |               30 | FR1001    |
|      10082 | NULL            |          10 |               40 | ZA1342    |
|      10098 | Carnival        |           3 |              120 | FR1001    |
|      20056 | 3D-Lego_Show    |           3 |              200 | UK3452    |
|      30011 | BlackHole2      |          12 |               34 | UK3452    |
|      30012 | Pirates         |          10 |               42 | UK3452    |
|      30044 | UnderSeaWord    |           4 |               80 | UK3452    |
|      98764 | GoldRush        |           5 |               80 | ZA1342    |
+------------+-----------------+-------------+------------------+-----------+
11 rows in set (0.00 sec)

MariaDB [themepark]> SELECT DISTINCT(PARK_CODE), ATTRACT_AGE FROM ATTRACTION;
+-----------+-------------+
| PARK_CODE | ATTRACT_AGE |
+-----------+-------------+
| FR1001    |          11 |
| FR1001    |           4 |
| FR1001    |          23 |
| ZA1342    |          10 |
| FR1001    |           3 |
| UK3452    |           3 |
| UK3452    |          12 |
| UK3452    |          10 |
| UK3452    |           4 |
| ZA1342    |           5 |
+-----------+-------------+
10 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT;
+----------+-----------------+------------+--------+---------+
| RollNo   | StName          | FName      | Gender | Contact |
+----------+-----------------+------------+--------+---------+
| p19-6012 | Arshad Arif     | Arif Ali   | M      | 123     |
| p19-6013 | Arshad Ali      | Ali        | M      | 124     |
| p19-6014 | Muhammad Arshad | Faizan Ali | M      | 125     |
| p19-6015 | Ahmad Ali       | Ali        | M      | 126     |
| p19-6016 | Ahmed Ali       | Ali        | M      | 127     |
+----------+-----------------+------------+--------+---------+
5 rows in set (0.01 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME = 'Arshad';
Empty set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT;
+----------+-----------------+------------+--------+---------+
| RollNo   | StName          | FName      | Gender | Contact |
+----------+-----------------+------------+--------+---------+
| p19-6012 | Arshad Arif     | Arif Ali   | M      | 123     |
| p19-6013 | Arshad Ali      | Ali        | M      | 124     |
| p19-6014 | Muhammad Arshad | Faizan Ali | M      | 125     |
| p19-6015 | Ahmad Ali       | Ali        | M      | 126     |
| p19-6016 | Ahmed Ali       | Ali        | M      | 127     |
+----------+-----------------+------------+--------+---------+
5 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE 'Arshad%';
+----------+-------------+----------+--------+---------+
| RollNo   | StName      | FName    | Gender | Contact |
+----------+-------------+----------+--------+---------+
| p19-6012 | Arshad Arif | Arif Ali | M      | 123     |
| p19-6013 | Arshad Ali  | Ali      | M      | 124     |
+----------+-------------+----------+--------+---------+
2 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE '%Arshad';
+----------+-----------------+------------+--------+---------+
| RollNo   | StName          | FName      | Gender | Contact |
+----------+-----------------+------------+--------+---------+
| p19-6014 | Muhammad Arshad | Faizan Ali | M      | 125     |
+----------+-----------------+------------+--------+---------+
1 row in set (0.00 sec)

MariaDB [themepark]> INSERT INTO STUDENT VALUES('P19-6017','Muhammad Arshad Ali', 'Ali', 'M', 128);
Query OK, 1 row affected (0.01 sec)

MariaDB [themepark]> SELECT * FROM STUDENT;
+----------+---------------------+------------+--------+---------+
| RollNo   | StName              | FName      | Gender | Contact |
+----------+---------------------+------------+--------+---------+
| p19-6012 | Arshad Arif         | Arif Ali   | M      | 123     |
| p19-6013 | Arshad Ali          | Ali        | M      | 124     |
| p19-6014 | Muhammad Arshad     | Faizan Ali | M      | 125     |
| p19-6015 | Ahmad Ali           | Ali        | M      | 126     |
| p19-6016 | Ahmed Ali           | Ali        | M      | 127     |
| P19-6017 | Muhammad Arshad Ali | Ali        | M      | 128     |
+----------+---------------------+------------+--------+---------+
6 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE '%Arshad';
+----------+-----------------+------------+--------+---------+
| RollNo   | StName          | FName      | Gender | Contact |
+----------+-----------------+------------+--------+---------+
| p19-6014 | Muhammad Arshad | Faizan Ali | M      | 125     |
+----------+-----------------+------------+--------+---------+
1 row in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE '%Arshad%';
+----------+---------------------+------------+--------+---------+
| RollNo   | StName              | FName      | Gender | Contact |
+----------+---------------------+------------+--------+---------+
| p19-6012 | Arshad Arif         | Arif Ali   | M      | 123     |
| p19-6013 | Arshad Ali          | Ali        | M      | 124     |
| p19-6014 | Muhammad Arshad     | Faizan Ali | M      | 125     |
| P19-6017 | Muhammad Arshad Ali | Ali        | M      | 128     |
+----------+---------------------+------------+--------+---------+
4 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT;
+----------+---------------------+------------+--------+---------+
| RollNo   | StName              | FName      | Gender | Contact |
+----------+---------------------+------------+--------+---------+
| p19-6012 | Arshad Arif         | Arif Ali   | M      | 123     |
| p19-6013 | Arshad Ali          | Ali        | M      | 124     |
| p19-6014 | Muhammad Arshad     | Faizan Ali | M      | 125     |
| p19-6015 | Ahmad Ali           | Ali        | M      | 126     |
| p19-6016 | Ahmed Ali           | Ali        | M      | 127     |
| P19-6017 | Muhammad Arshad Ali | Ali        | M      | 128     |
+----------+---------------------+------------+--------+---------+
6 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE 'Ahm_d Ali';
+----------+-----------+-------+--------+---------+
| RollNo   | StName    | FName | Gender | Contact |
+----------+-----------+-------+--------+---------+
| p19-6015 | Ahmad Ali | Ali   | M      | 126     |
| p19-6016 | Ahmed Ali | Ali   | M      | 127     |
+----------+-----------+-------+--------+---------+
2 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE 'M%Arshad%';
+----------+---------------------+------------+--------+---------+
| RollNo   | StName              | FName      | Gender | Contact |
+----------+---------------------+------------+--------+---------+
| p19-6014 | Muhammad Arshad     | Faizan Ali | M      | 125     |
| P19-6017 | Muhammad Arshad Ali | Ali        | M      | 128     |
+----------+---------------------+------------+--------+---------+
2 rows in set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE 'M%Arshad%A';
Empty set (0.00 sec)

MariaDB [themepark]> SELECT * FROM STUDENT WHERE STNAME LIKE 'M%Arshad%A%';
+----------+---------------------+-------+--------+---------+
| RollNo   | StName              | FName | Gender | Contact |
+----------+---------------------+-------+--------+---------+
| P19-6017 | Muhammad Arshad Ali | Ali   | M      | 128     |
+----------+---------------------+-------+--------+---------+
1 row in set (0.00 sec)

MariaDB [themepark]>
