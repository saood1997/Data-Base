				(1)

CREATE OR REPLACE PROCEDURE PRICE(in CODE VARCHAR(10) , out ONHAND float)
BEGIN
SELECT P_ONHAND INTO ONHAND FROM PRODUCT where 'P
_CODE' = 'CODE';
END


<?php
    	    include "connect.php";

            $sql = 'CALL PRICE ("13-Q2/P2",@out)';

            $out = "select @out;";

            $res = $con->query($out);
	    $row = $res->fetch_assoc();
	    	
	    echo $row["@out"];

?>







