

				part(a)


CREATE OR REPLACE PROCEDURE user_insert(in user_id int,in username    varchar(15),in password char(15),in email varchar(40))
BEGIN
INSERT INTO users values(user_id,username,password,email);
END


CALL user_inseret(1,'abc123','def321','abc1213@yahoo.com')


				

				part(b)


DELIMITER $$
CREATE
TRIGGER user_insert AFTER insert
ON users
FOR EACH ROW BEGIN
set @newyahoo = 0;
set @newgmail = 0;
set @newhotmail = 0;
if locate('yahoo',new.email)
then
set @newyahoo = 1;
end if;
if locate('gmail',new.email)
then
set @newgamil = 1;
end if;
if locate('hotmail',new.email)
then
set @newhotmail = 1;
end if;


update summary set total_users = total_users + 1, yahoo = yahoo+@newyahoo, gmail = gmail + @newgmail,hotmail = hotmail+@newhotmail;
end

drop trigger user_insert


create trigger user_delete after delete on users
for each row begin
set @yahoo = (select count(email) from users where email like '%yahoo%');
set @hotmail = (select count(email) from users where email like '%hotmail%');
set @gmail = (select count(email) from users where email like '%gmail%');
set @total = @yahoo + @hotmail +@gmail;
update summary set total_users = @total,yahoo = @yahoo, hotmail = @hotmail,gmail = @gmail;
end

create trigger user_update after update on users
for each row begin
set @yahoo = (select count(email) from users where email like '%yahoo%');
set @hotmail = (select count(email) from users where email like '%hotmail%');
set @gmail = (select count(email) from users where email like '%gmail%');
set @total = @yahoo + @hotmail +@gmail;
update summary set total_users = @total,yahoo = @yahoo, hotmail = @hotmail,gmail = @gmail;
end
